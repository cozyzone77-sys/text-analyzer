#!/usr/bin/env python3
"""Local-only round-robin gateway for testing multiple real API processes."""

from __future__ import annotations

import argparse
import http.client
import os
import pathlib
import shutil
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

API_DIR = pathlib.Path(__file__).resolve().parents[1]
API_ENTRY = API_DIR / "dist" / "index.mjs"


class RoundRobinGateway:
    def __init__(self, ports: list[int]):
        self.ports = ports
        self.lock = threading.Lock()
        self.next_index = 0
        self.processes: list[subprocess.Popen[bytes]] = []

    def next_port(self) -> int:
        with self.lock:
            port = self.ports[self.next_index]
            self.next_index = (self.next_index + 1) % len(self.ports)
            return port

    def stop_instances(self) -> None:
        for process in self.processes:
            if process.poll() is None:
                process.terminate()
        for process in self.processes:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)


def handler_for(gateway: RoundRobinGateway) -> type[BaseHTTPRequestHandler]:
    class ProxyHandler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def do_GET(self) -> None:
            port = gateway.next_port()
            connection = http.client.HTTPConnection("127.0.0.1", port, timeout=60)
            headers = {
                name: value
                for name, value in self.headers.items()
                if name.lower() not in {"host", "connection", "content-length"}
            }
            try:
                connection.request("GET", self.path, headers=headers)
                upstream = connection.getresponse()
                body = upstream.read()
                self.send_response(upstream.status)
                for name, value in upstream.getheaders():
                    if name.lower() not in {
                        "connection",
                        "content-length",
                        "date",
                        "server",
                        "transfer-encoding",
                    }:
                        self.send_header(name, value)
                self.send_header("X-API-Process-Root", str(os.getpid()))
                self.send_header("X-API-Instance-Port", str(port))
                self.send_header("X-Load-Balancer-Policy", "round-robin")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except (OSError, http.client.HTTPException) as error:
                body = f'{{"error":"local API instance unavailable: {error}"}}'.encode()
                try:
                    self.send_response(502)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                except OSError:
                    pass
            finally:
                connection.close()

        def log_message(self, fmt: str, *args: object) -> None:
            print(f"[round-robin] {self.address_string()} {fmt % args}", flush=True)

    return ProxyHandler


def wait_for_instance(port: int, process: subprocess.Popen[bytes]) -> None:
    deadline = time.monotonic() + 30
    url = f"http://127.0.0.1:{port}/api/healthz"
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f"API process on port {port} exited with code {process.returncode}")
        try:
            with urllib.request.urlopen(url, timeout=1) as response:
                if response.status == 200:
                    return
        except (OSError, urllib.error.URLError) as error:
            last_error = error
        time.sleep(0.1)
    raise RuntimeError(f"API process on port {port} did not become healthy: {last_error}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--instances", type=int, default=4)
    parser.add_argument("--listen-port", type=int, default=18080)
    parser.add_argument("--port-base", type=int, default=18100)
    args = parser.parse_args()
    if not 2 <= args.instances <= 16:
        parser.error("--instances must be between 2 and 16")
    if args.listen_port in range(args.port_base, args.port_base + args.instances):
        parser.error("gateway and API instance ports must be different")
    if not API_ENTRY.is_file():
        parser.error(f"{API_ENTRY} is missing; build the API server before starting the gateway")
    node = shutil.which("node")
    if not node:
        parser.error("node executable was not found")

    ports = list(range(args.port_base, args.port_base + args.instances))
    gateway = RoundRobinGateway(ports)
    environment = os.environ.copy()
    environment["NODE_ENV"] = "development"
    environment["API_WORKERS"] = "1"
    try:
        for index, port in enumerate(ports):
            instance_environment = {
                **environment,
                "PORT": str(port),
                "ADMISSIONS_INSTANCE_INDEX": str(index),
            }
            process = subprocess.Popen(
                [node, "--enable-source-maps", str(API_ENTRY)],
                cwd=API_DIR,
                env=instance_environment,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            gateway.processes.append(process)
            wait_for_instance(port, process)
            print(f"API instance {index + 1}/{args.instances} ready on 127.0.0.1:{port} (pid {process.pid})", flush=True)

        server = ThreadingHTTPServer(
            ("127.0.0.1", args.listen_port),
            handler_for(gateway),
        )
        server.daemon_threads = True

        def request_shutdown(_signum: int, _frame: object) -> None:
            threading.Thread(target=server.shutdown, daemon=True).start()

        signal.signal(signal.SIGTERM, request_shutdown)
        signal.signal(signal.SIGINT, request_shutdown)
        print(
            f"Round-robin gateway listening on 127.0.0.1:{args.listen_port}; "
            f"{args.instances} independent API processes",
            flush=True,
        )
        try:
            server.serve_forever(poll_interval=0.2)
        finally:
            server.server_close()
    finally:
        gateway.stop_instances()


if __name__ == "__main__":
    main()
