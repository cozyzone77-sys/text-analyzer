import { Router, type IRouter } from "express";
import admissionsRouter from "./admissions";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(healthRouter);
router.use(admissionsRouter);

export default router;
