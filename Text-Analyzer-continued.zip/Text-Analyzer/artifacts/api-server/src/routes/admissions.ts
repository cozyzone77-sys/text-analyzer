import { execFile } from "node:child_process";
import path from "node:path";
import { performance } from "node:perf_hooks";
import { Router, type IRouter } from "express";
import {
  GetAdmissionsQueryParams,
  GetAdmissionsResponse,
  GetAdmissionsSummaryResponse,
  GetPerformanceMetricsResponse,
} from "@workspace/api-zod";
import {
  getPerformanceMetrics,
  recordAdmissionRequest,
  trackPythonProcess,
  untrackPythonProcess,
} from "../lib/performance-metrics";

const router: IRouter = Router();
const repositoryPath = path.resolve(
  process.cwd(),
  "python/admissions_repository.py",
);

type RepositoryResult<T> = {
  value: T;
  sqliteQueryMs: number;
  pythonProcessMs: number;
};

type AdmissionsCacheStatus = "BYPASS" | "MISS" | "HIT" | "COALESCED";
const admissionsCache = new Map<
  string,
  { value: unknown[]; expiresAt: number }
>();
const admissionsInFlight = new Map<
  string,
  Promise<RepositoryResult<unknown[]>>
>();

async function callRepository<T>(
  operation: "list" | "summary",
  parameters: Record<string, unknown>,
): Promise<RepositoryResult<T>> {
  const startedAt = performance.now();
  const { stdout } = await new Promise<{ stdout: string }>((resolve, reject) => {
    const child = execFile(
      "python3",
      [repositoryPath, operation, JSON.stringify(parameters)],
      {
        cwd: process.cwd(),
        timeout: 30_000,
        maxBuffer: 8 * 1024 * 1024,
      },
      (error, output, stderr) => {
        if (error) {
          reject(new Error(stderr.trim() || error.message));
          return;
        }
        resolve({ stdout: output });
      },
    );
    trackPythonProcess(child.pid);
    child.once("close", () => untrackPythonProcess(child.pid));
  });
  const pythonProcessMs = performance.now() - startedAt;
  const parsed = JSON.parse(stdout) as { sqliteQueryMs: number } & (
    | { items: T }
    | { summary: T }
  );
  return {
    value: "items" in parsed ? parsed.items : parsed.summary,
    sqliteQueryMs: parsed.sqliteQueryMs,
    pythonProcessMs,
  };
}

async function getAdmissions(
  key: string,
  parameters: Record<string, unknown>,
): Promise<{ result: RepositoryResult<unknown[]>; cacheStatus: AdmissionsCacheStatus }> {
  const now = Date.now();
  const cached = admissionsCache.get(key);
  if (cached && cached.expiresAt > now) {
    return {
      result: {
        value: cached.value,
        pythonProcessMs: 0,
        sqliteQueryMs: 0,
      },
      cacheStatus: "HIT",
    };
  }
  if (cached) admissionsCache.delete(key);

  const pending = admissionsInFlight.get(key);
  if (pending) {
    return { result: await pending, cacheStatus: "COALESCED" };
  }

  const repositoryRequest = callRepository<unknown[]>("list", parameters);
  admissionsInFlight.set(key, repositoryRequest);
  try {
    const result = await repositoryRequest;
    for (const [entryKey, entry] of admissionsCache) {
      if (entry.expiresAt <= now) admissionsCache.delete(entryKey);
    }
    if (admissionsCache.size >= 500) {
      const oldestKey = admissionsCache.keys().next().value;
      if (oldestKey !== undefined) admissionsCache.delete(oldestKey);
    }
    admissionsCache.set(key, {
      value: result.value,
      expiresAt: Date.now() + 30_000,
    });
    return { result, cacheStatus: "MISS" };
  } finally {
    admissionsInFlight.delete(key);
  }
}

function setTimingHeaders(
  res: { setHeader(name: string, value: string): unknown },
  totalMs: number,
  pythonProcessMs: number,
  sqliteQueryMs: number,
): void {
  res.setHeader("X-Total-Response-Ms", totalMs.toFixed(3));
  res.setHeader("X-Python-Process-Ms", pythonProcessMs.toFixed(3));
  res.setHeader("X-SQLite-Query-Ms", sqliteQueryMs.toFixed(3));
  res.setHeader(
    "Server-Timing",
    `pythonProcess;dur=${pythonProcessMs.toFixed(3)}, sqliteQuery;dur=${sqliteQueryMs.toFixed(3)}`,
  );
}

router.get("/admissions", async (req, res): Promise<void> => {
  const parsedQuery = GetAdmissionsQueryParams.safeParse(req.query);
  if (!parsedQuery.success) {
    res.status(400).json({ error: parsedQuery.error.message });
    return;
  }

  const startedAt = performance.now();
  try {
    const cacheEnabled = req.get("x-admissions-performance-cache") === "1";
    const cacheKey = JSON.stringify({
      query: parsedQuery.data,
      run: req.get("x-admissions-cache-run") ?? "default",
    });
    const { result, cacheStatus } = cacheEnabled
      ? await getAdmissions(cacheKey, parsedQuery.data)
      : {
          result: await callRepository<unknown[]>("list", parsedQuery.data),
          cacheStatus: "BYPASS" as const,
        };
    const totalMs = performance.now() - startedAt;
    const admissions = GetAdmissionsResponse.parse(result.value);
    setTimingHeaders(res, totalMs, result.pythonProcessMs, result.sqliteQueryMs);
    res.setHeader("X-Admissions-Cache", cacheStatus);
    res.setHeader("X-API-Instance-PID", String(process.pid));
    res.setHeader("X-API-Process-Root", String(process.pid));
    recordAdmissionRequest({
      totalMs,
      pythonProcessMs: result.pythonProcessMs,
      sqliteQueryMs: result.sqliteQueryMs,
    });
    res.json(admissions);
  } catch (error) {
    req.log.error({ err: error }, "Could not read admissions from SQLite");
    res.status(500).json({ error: "입시 일정 샘플 데이터를 불러오지 못했습니다." });
  }
});

router.get("/admissions/summary", async (req, res): Promise<void> => {
  try {
    const result = await callRepository<Record<string, unknown>>("summary", {});
    res.json(GetAdmissionsSummaryResponse.parse(result.value));
  } catch (error) {
    req.log.error({ err: error }, "Could not read the admissions summary");
    res.status(500).json({ error: "입시 일정 요약을 불러오지 못했습니다." });
  }
});

router.get("/performance/metrics", (_req, res): void => {
  res.json(GetPerformanceMetricsResponse.parse(getPerformanceMetrics()));
});

export default router;
