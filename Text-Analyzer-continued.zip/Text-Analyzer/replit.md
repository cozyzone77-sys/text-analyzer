# Admissions Performance Lab

A Korean-language sample admissions guide and repeatable performance experiment for tracing requests through Express, a fresh Python process, and SQLite.

## Run & Operate

- Run the API: `pnpm --filter @workspace/api-server run dev`
- Run the web app: `pnpm --filter @workspace/admissions-performance-lab run dev`
- Run the local benchmark: `python3 artifacts/api-server/python/admissions_load_test.py`
- Run all TypeScript checks: `pnpm run typecheck`
- Regenerate API contracts after editing OpenAPI: `pnpm --filter @workspace/api-spec run codegen`

The benchmark defaults to `http://localhost:80/api/admissions` and runs 1, 10, 25, 50, and 100 concurrent requests, 100 requests at each level, with a two-second pause between levels. It refuses non-local targets.

## Product

- `/` is a searchable, filterable admissions schedule guide.
- `/performance` runs the specified local concurrency experiment and displays browser timings, rolling API/Python/SQLite timings, CPU/RSS readings, and the historical baseline.
- Every schedule row is synthetic test data, not official admissions information. Verify dates with each university's official admissions materials before using them for an application.

## Architecture decisions

- The experiment intentionally follows browser → Express API → a new Python subprocess → SQLite for each admissions request. This makes process startup/wait time measurable separately from the Python SQLite `SELECT` + `fetchall` interval.
- SQLite is stored as an ignored local file at `artifacts/api-server/python/data/admissions.db`; the Python standard library is sufficient, so the experimental data path does not require a separately managed PostgreSQL schema or service.
- `pythonProcessMs` includes `sqliteQueryMs`. These are overlapping measurements and must not be added together.
- Resource readings are sampled approximately every 100 ms from Linux process data. Short-lived Python children may not appear in every sample; treat these readings as estimates, not profiler-grade accounting.
- The earlier 500-request run is preserved in the web UI and load-test script as a single-run reference, not as a statistically conclusive benchmark.

## User preferences

- When changing code, explain both what changed and why the change is needed for the experiment.

## Pointers

- `lib/api-spec/openapi.yaml` — API contract source of truth
- `artifacts/api-server/python/admissions_repository.py` — SQLite setup, sample rows, and queries
- `artifacts/api-server/python/admissions_load_test.py` — local repeatable CLI benchmark
- `artifacts/api-server/src/routes/admissions.ts` — API-to-Python integration and timing headers
- `artifacts/api-server/src/lib/performance-metrics.ts` — rolling timing/resource measurements
- `artifacts/admissions-performance-lab/src/App.tsx` — admissions and performance screens
