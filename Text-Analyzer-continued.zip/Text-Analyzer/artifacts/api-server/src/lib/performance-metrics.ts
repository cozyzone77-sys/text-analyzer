import { readFile } from "node:fs/promises";
import { performance } from "node:perf_hooks";
import { cpuUsage, memoryUsage } from "node:process";

type RequestSample = {
  totalMs: number;
  pythonProcessMs: number;
  sqliteQueryMs: number;
};

type ResourceSample = {
  apiCpu: number;
  apiRssMb: number;
  pythonCpu: number;
  pythonRssMb: number;
  pythonProcesses: number;
};

const requestSamples: RequestSample[] = [];
const resourceSamples: ResourceSample[] = [];
const pythonPids = new Set<number>();
const previousPythonTicks = new Map<number, number>();
let previousCpu = cpuUsage();
let previousSampleAt = performance.now();
let sampling = false;

const keepLatest = <T,>(items: T[], item: T, capacity: number): void => {
  items.push(item);
  if (items.length > capacity) items.splice(0, items.length - capacity);
};

export function trackPythonProcess(pid: number | undefined): void {
  if (pid !== undefined) pythonPids.add(pid);
}

export function untrackPythonProcess(pid: number | undefined): void {
  if (pid !== undefined) {
    pythonPids.delete(pid);
    previousPythonTicks.delete(pid);
  }
}

export function recordAdmissionRequest(sample: RequestSample): void {
  keepLatest(requestSamples, sample, 500);
}

async function readPythonProcess(pid: number): Promise<{ ticks: number; rssMb: number } | null> {
  try {
    const [stat, status] = await Promise.all([
      readFile(`/proc/${pid}/stat`, "utf8"),
      readFile(`/proc/${pid}/status`, "utf8"),
    ]);
    const fields = stat.slice(stat.lastIndexOf(")") + 2).trim().split(/\s+/);
    const ticks = Number(fields[11]) + Number(fields[12]);
    const rss = status.match(/^VmRSS:\s+(\d+)\s+kB$/m);
    if (!Number.isFinite(ticks)) return null;
    return { ticks, rssMb: rss ? Number(rss[1]) / 1024 : 0 };
  } catch {
    return null;
  }
}

async function sampleResources(): Promise<void> {
  if (sampling) return;
  sampling = true;
  try {
    const now = performance.now();
    const elapsedMs = Math.max(1, now - previousSampleAt);
    const cpu = cpuUsage(previousCpu);
    previousCpu = cpuUsage();
    previousSampleAt = now;
    const apiCpu = ((cpu.user + cpu.system) / 1000 / elapsedMs) * 100;

    const processStats = await Promise.all([...pythonPids].map(async (pid) => ({
      pid,
      stats: await readPythonProcess(pid),
    })));
    let pythonCpu = 0;
    let pythonRssMb = 0;
    let liveProcesses = 0;
    for (const { pid, stats } of processStats) {
      if (!stats) {
        untrackPythonProcess(pid);
        continue;
      }
      liveProcesses += 1;
      pythonRssMb += stats.rssMb;
      const oldTicks = previousPythonTicks.get(pid);
      if (oldTicks !== undefined) {
        pythonCpu += (Math.max(0, stats.ticks - oldTicks) * 10 / elapsedMs) * 100;
      }
      previousPythonTicks.set(pid, stats.ticks);
    }

    keepLatest(resourceSamples, {
      apiCpu: Math.max(0, apiCpu),
      apiRssMb: memoryUsage().rss / (1024 * 1024),
      pythonCpu: Math.max(0, pythonCpu),
      pythonRssMb,
      pythonProcesses: liveProcesses,
    }, 1200);
  } finally {
    sampling = false;
  }
}

const average = (values: number[]): number =>
  values.length === 0 ? 0 : values.reduce((sum, value) => sum + value, 0) / values.length;

const rounded = (value: number): number => Math.round(value * 1000) / 1000;

function summarize(values: number[]) {
  if (values.length === 0) {
    return { averageMs: 0, medianMs: 0, p95Ms: 0, minimumMs: 0, maximumMs: 0, samples: 0 };
  }
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return {
    averageMs: rounded(average(values)),
    medianMs: rounded(sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2),
    p95Ms: rounded(sorted[Math.max(0, Math.ceil(sorted.length * 0.95) - 1)]),
    minimumMs: rounded(sorted[0]),
    maximumMs: rounded(sorted[sorted.length - 1]),
    samples: values.length,
  };
}

function summarizeMaximum(values: number[]): number {
  return values.length === 0 ? 0 : Math.max(...values);
}

export function getPerformanceMetrics() {
  const resourceData = resourceSamples;
  return {
    totalResponse: summarize(requestSamples.map((sample) => sample.totalMs)),
    pythonProcess: summarize(requestSamples.map((sample) => sample.pythonProcessMs)),
    sqliteQuery: summarize(requestSamples.map((sample) => sample.sqliteQueryMs)),
    resources: {
      apiServerAverageCpuPercent: rounded(average(resourceData.map((sample) => sample.apiCpu))),
      apiServerMaximumCpuPercent: rounded(summarizeMaximum(resourceData.map((sample) => sample.apiCpu))),
      apiServerAverageRssMb: rounded(average(resourceData.map((sample) => sample.apiRssMb))),
      apiServerMaximumRssMb: rounded(summarizeMaximum(resourceData.map((sample) => sample.apiRssMb))),
      pythonAverageCpuPercent: rounded(average(resourceData.map((sample) => sample.pythonCpu))),
      pythonMaximumCpuPercent: rounded(summarizeMaximum(resourceData.map((sample) => sample.pythonCpu))),
      pythonAverageRssMb: rounded(average(resourceData.map((sample) => sample.pythonRssMb))),
      pythonMaximumRssMb: rounded(summarizeMaximum(resourceData.map((sample) => sample.pythonRssMb))),
      averagePythonProcesses: rounded(average(resourceData.map((sample) => sample.pythonProcesses))),
      maximumPythonProcesses: Math.round(summarizeMaximum(resourceData.map((sample) => sample.pythonProcesses))),
      samples: resourceData.length,
    },
    measuredRequests: requestSamples.length,
    measurementWindow: `최대 최근 ${requestSamples.length}회의 admissions 요청, 최근 ${resourceData.length}개 자원 샘플`,
    note: "pythonProcess 시간에는 sqliteQuery 시간이 포함됩니다. 둘을 합산하지 마세요. 자원은 100ms 간격으로 표본화하며 짧게 실행되는 하위 프로세스는 관측에서 빠질 수 있습니다. CPU는 여러 스레드/프로세스의 합계라 100%를 넘을 수 있습니다.",
  };
}

const sampler = setInterval(() => {
  void sampleResources();
}, 100);
sampler.unref();
