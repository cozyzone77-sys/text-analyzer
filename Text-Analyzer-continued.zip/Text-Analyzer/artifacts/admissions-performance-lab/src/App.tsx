import { type ReactNode, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  getGetAdmissionsQueryKey,
  getGetAdmissionsSummaryQueryKey,
  getGetPerformanceMetricsQueryKey,
  useGetAdmissions,
  useGetAdmissionsSummary,
  useGetPerformanceMetrics,
  type Admission,
  type GetAdmissionsDirection,
  type GetAdmissionsSort,
} from '@workspace/api-client-react';
import {
  AlertTriangle,
  ArrowDown,
  ArrowDownUp,
  ArrowUp,
  BookOpen,
  CalendarClock,
  CircleHelp,
  Database,
  Gauge,
  GraduationCap,
  Play,
  RefreshCw,
  Search,
  Server,
  Square,
  Users,
  X,
} from 'lucide-react';
import {
  Link,
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();
const CONCURRENCY_STEPS = [1, 10, 25, 50, 100] as const;
const REQUESTS_PER_STEP = 100;
const INTER_STEP_DELAY_MS = 2000;
const BASELINE = [
  { concurrency: 1, avg: 74.88, p95: 93.10, rps: 13.34 },
  { concurrency: 10, avg: 333.31, p95: 531.84, rps: 29.33 },
  { concurrency: 25, avg: 939.68, p95: 1563.36, rps: 25.33 },
  { concurrency: 50, avg: 1832.93, p95: 4092.94, rps: 23.27 },
  { concurrency: 100, avg: 1763.25, p95: 2619.98, rps: 34.83 },
];

type StageResult = {
  concurrency: number;
  average: number;
  median: number;
  p95: number;
  minimum: number;
  maximum: number;
  succeeded: number;
  failed: number;
  elapsed: number;
  rps: number;
};

function formatDate(value?: string | null) {
  if (!value) return '미정';
  const parsed = new Date(`${value}T00:00:00`);
  if (Number.isNaN(parsed.getTime())) return value;
  return new Intl.DateTimeFormat('ko-KR', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(parsed);
}

function formatMs(value?: number) {
  return typeof value === 'number' && Number.isFinite(value) ? `${value.toFixed(2)} ms` : '—';
}

function numberValue(value?: number) {
  return typeof value === 'number' && Number.isFinite(value) ? value.toLocaleString('ko-KR', { maximumFractionDigits: 2 }) : '—';
}

function percentile(values: number[], percentileValue: number) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.min(sorted.length - 1, Math.ceil(percentileValue * sorted.length) - 1)];
}

function calculateStage(concurrency: number, times: number[], succeeded: number, failed: number, elapsed: number): StageResult {
  const sum = times.reduce((total, value) => total + value, 0);
  return {
    concurrency,
    average: times.length ? sum / times.length : 0,
    median: percentile(times, 0.5),
    p95: percentile(times, 0.95),
    minimum: times.length ? Math.min(...times) : 0,
    maximum: times.length ? Math.max(...times) : 0,
    succeeded,
    failed,
    elapsed,
    rps: elapsed > 0 ? (succeeded + failed) / (elapsed / 1000) : 0,
  };
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return (
    <div className="app-shell">
      <header className="topbar">
        <Link href="/" className="brand" aria-label="입시 일정 실험실 홈">
          <span className="brand-mark"><GraduationCap size={19} strokeWidth={2.2} /></span>
          <span>일정 실험실</span>
        </Link>
        <nav className="nav-links" aria-label="주요 메뉴">
          <Link href="/" className={`nav-link ${location === '/' ? 'active' : ''}`} data-testid="link-admissions">
            <BookOpen size={16} /> 전형 일정
          </Link>
          <Link href="/performance" className={`nav-link ${location === '/performance' ? 'active' : ''}`} data-testid="link-performance">
            <Gauge size={16} /> 성능 실험
          </Link>
        </nav>
      </header>
      {children}
      <footer className="footer-note">
        <span>입시 일정 실험실 · 한국어 안내</span>
        <span>샘플 데이터는 공식 전형 정보가 아닙니다.</span>
      </footer>
    </div>
  );
}

function LoadingRows() {
  return (
    <div className="loading-state" role="status" aria-label="일정을 불러오는 중">
      <div style={{ display: 'grid', gap: 13, maxWidth: 530, margin: 'auto' }}>
        {[0, 1, 2, 3].map((row) => <div className="skeleton" key={row} style={{ width: `${100 - row * 7}%`, height: 18 }} />)}
      </div>
      <p>전형 일정을 불러오고 있습니다.</p>
    </div>
  );
}

function AdmissionsPage() {
  const [search, setSearch] = useState('');
  const [university, setUniversity] = useState('');
  const [admissionType, setAdmissionType] = useState('');
  const [sort, setSort] = useState<GetAdmissionsSort>('date');
  const [direction, setDirection] = useState<GetAdmissionsDirection>('asc');
  const params = useMemo(() => ({
    ...(search.trim() ? { search: search.trim() } : {}),
    ...(university.trim() ? { university: university.trim() } : {}),
    ...(admissionType ? { admissionType } : {}),
    sort,
    direction,
  }), [search, university, admissionType, sort, direction]);
  const admissionsQuery = useGetAdmissions(params, { query: { queryKey: getGetAdmissionsQueryKey(params) } });
  const summaryQuery = useGetAdmissionsSummary({ query: { queryKey: getGetAdmissionsSummaryQueryKey() } });
  const admissions = admissionsQuery.data as Admission[] | undefined;
  const options = useMemo(() => [...new Set((admissions ?? []).map((item) => item.admissionType).filter(Boolean))].sort(), [admissions]);
  const summary = summaryQuery.data;

  function resetFilters() {
    setSearch('');
    setUniversity('');
    setAdmissionType('');
    setSort('date');
    setDirection('asc');
  }

  return (
    <Shell>
      <main className="page">
        <div className="hero-row">
          <div>
            <div className="eyebrow">CLASSROOM / ADMISSIONS INDEX</div>
            <h1 className="page-title">전형 일정, 한눈에.</h1>
            <p className="page-subtitle">우리 반이 함께 살펴보는 대학별 전형 일정 모음</p>
          </div>
          <button className="icon-button" type="button" onClick={() => { void admissionsQuery.refetch(); void summaryQuery.refetch(); }} aria-label="일정 새로고침" data-testid="button-refresh-admissions">
            <RefreshCw size={15} /> 새로고침
          </button>
        </div>

        <div className="sample-warning" role="note" data-testid="notice-sample-data">
          <AlertTriangle size={17} />
          <span><strong>실험용 샘플 데이터입니다.</strong> 아래 전형 일정은 공식 자료가 아니며, 실제 지원 전 반드시 대학의 공식 모집요강과 일정을 확인하세요.</span>
        </div>

        <section className="summary-grid" aria-label="일정 요약">
          <SummaryCard label="등록된 전형" value={summary ? `${summary.total}` : '—'} icon={<BookOpen size={14} />} testId="summary-total" loading={summaryQuery.isLoading} />
          <SummaryCard label="대학 수" value={summary ? `${summary.universities}` : '—'} icon={<GraduationCap size={15} />} testId="summary-universities" loading={summaryQuery.isLoading} />
          <SummaryCard label="전형 유형" value={summary ? `${summary.admissionTypes}` : '—'} icon={<Users size={14} />} testId="summary-types" loading={summaryQuery.isLoading} />
          <SummaryCard label="가장 가까운 마감" value={summary ? formatDate(summary.nextDeadline) : '—'} icon={<CalendarClock size={14} />} testId="summary-deadline" loading={summaryQuery.isLoading} small />
        </section>

        <section className="panel" aria-label="전형 일정 검색 결과">
          <div className="filters">
            <label className="search-wrap">
              <Search size={16} aria-hidden="true" />
              <input
                className="control search-input"
                type="search"
                placeholder="대학명 또는 키워드 검색"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                aria-label="대학명 또는 키워드 검색"
                data-testid="input-admission-search"
              />
            </label>
            <input
              className="control select-control"
              type="search"
              placeholder="대학명으로 좁히기"
              value={university}
              onChange={(event) => setUniversity(event.target.value)}
              aria-label="대학명 필터"
              data-testid="input-university-filter"
            />
            <select className="control select-control" value={admissionType} onChange={(event) => setAdmissionType(event.target.value)} aria-label="전형 유형 필터" data-testid="select-admission-type">
              <option value="">모든 전형 유형</option>
              {options.map((option) => <option value={option} key={option}>{option}</option>)}
            </select>
            <button className="sort-toggle" type="button" onClick={() => setSort((current) => current === 'date' ? 'university' : 'date')} aria-label={`정렬 기준: ${sort === 'date' ? '접수 시작일' : '대학명'}`} data-testid="button-sort-field">
              <ArrowDownUp size={14} /> {sort === 'date' ? '접수일' : '대학명'}
            </button>
            <button className="sort-toggle" type="button" onClick={() => setDirection((current) => current === 'asc' ? 'desc' : 'asc')} aria-label={`정렬 방향: ${direction === 'asc' ? '오름차순' : '내림차순'}`} data-testid="button-sort-direction">
              {direction === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
              {direction === 'asc' ? '오름차순' : '내림차순'}
            </button>
          </div>
          <div className="results-head">
            <strong>모집 일정</strong>
            <span className="results-count" data-testid="text-admission-count">{admissions ? `${admissions.length}건 표시` : '일정 조회 중'}</span>
          </div>
          {admissionsQuery.isLoading ? <LoadingRows /> : admissionsQuery.isError ? (
            <div className="error-state" role="alert">
              <div className="empty-mark"><AlertTriangle size={20} /></div>
              <h3>일정을 불러오지 못했습니다</h3>
              <p>연결 상태를 확인한 뒤 다시 시도해 주세요.</p>
              <button className="action-button" type="button" onClick={() => void admissionsQuery.refetch()} data-testid="button-retry-admissions"><RefreshCw size={14} /> 다시 시도</button>
            </div>
          ) : !admissions?.length ? (
            <div className="empty-state" data-testid="empty-admissions">
              <div className="empty-mark"><Search size={19} /></div>
              <h3>조건에 맞는 일정이 없습니다</h3>
              <p>검색어와 필터를 바꾸거나 전체 일정을 다시 확인해 보세요.</p>
              <button className="action-button secondary-button" type="button" onClick={resetFilters} data-testid="button-reset-filters"><X size={14} /> 필터 초기화</button>
            </div>
          ) : (
            <div className="table-scroll">
              <table className="admission-table">
                <thead><tr><th>대학 / 전형</th><th>접수 기간</th><th>서류 마감</th><th>시험일</th><th>발표일</th><th>메모</th></tr></thead>
                <tbody>
                  {admissions.map((item) => (
                    <tr key={item.id} data-testid={`row-admission-${item.id}`}>
                      <td><div className="university">{item.university}{item.isSample && <span className="row-sample">샘플</span>}</div><div style={{ marginTop: 7 }}><span className="type-tag">{item.admissionType}</span></div></td>
                      <td><div className="date-main">{formatDate(item.applicationStart)}</div><div className="date-sub">~ {formatDate(item.applicationEnd)}</div></td>
                      <td><div className="date-main">{formatDate(item.documentDeadline)}</div></td>
                      <td><div className="date-main">{formatDate(item.examDate)}</div></td>
                      <td><div className="date-main">{formatDate(item.resultDate)}</div></td>
                      <td className="notes-cell">{item.notes || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
        {summaryQuery.isError && <div className="error-inline" style={{ marginTop: 12 }} role="alert"><span>일정 요약을 불러오지 못했습니다.</span><button className="small-link" type="button" onClick={() => void summaryQuery.refetch()}>다시 시도</button></div>}
      </main>
    </Shell>
  );
}

function SummaryCard({ label, value, icon, testId, loading, small = false }: { label: string; value: string; icon: ReactNode; testId: string; loading: boolean; small?: boolean }) {
  return (
    <div className="summary-card" data-testid={testId}>
      <div className="summary-label">{icon}{label}</div>
      {loading ? <div className="skeleton" style={{ width: '65%', marginTop: 12, height: 25 }} /> : <div className={`summary-value ${small ? 'small' : ''}`}>{value}</div>}
    </div>
  );
}

function PerformancePage() {
  const metricsQuery = useGetPerformanceMetrics({ query: { queryKey: getGetPerformanceMetricsQueryKey() } });
  const metrics = metricsQuery.data;
  const [running, setRunning] = useState(false);
  const [currentStage, setCurrentStage] = useState<number | null>(null);
  const [currentCompleted, setCurrentCompleted] = useState(0);
  const [results, setResults] = useState<StageResult[]>([]);
  const [runError, setRunError] = useState('');
  const stopRequested = useRef(false);
  const activeControllers = useRef<AbortController[]>([]);

  async function runStage(concurrency: number): Promise<StageResult | null> {
    const timings: number[] = [];
    let succeeded = 0;
    let failed = 0;
    let cursor = 0;
    const started = performance.now();
    const worker = async () => {
      while (!stopRequested.current) {
        const index = cursor++;
        if (index >= REQUESTS_PER_STEP) return;
        const controller = new AbortController();
        activeControllers.current.push(controller);
        const requestStart = performance.now();
        try {
          const response = await fetch('/api/admissions', {
            method: 'GET',
            headers: { Accept: 'application/json' },
            cache: 'no-store',
            signal: controller.signal,
          });
          await response.arrayBuffer();
          timings.push(performance.now() - requestStart);
          if (response.ok) succeeded += 1;
          else failed += 1;
          setCurrentCompleted((count) => count + 1);
        } catch (error) {
          timings.push(performance.now() - requestStart);
          if (!(error instanceof DOMException && error.name === 'AbortError')) {
            failed += 1;
            setCurrentCompleted((count) => count + 1);
          }
        } finally {
          activeControllers.current = activeControllers.current.filter((item) => item !== controller);
        }
      }
    };
    await Promise.all(Array.from({ length: concurrency }, () => worker()));
    if (stopRequested.current) return null;
    return calculateStage(concurrency, timings, succeeded, failed, performance.now() - started);
  }

  async function startRun() {
    if (running) return;
    stopRequested.current = false;
    setRunError('');
    setResults([]);
    setRunning(true);
    try {
      for (let index = 0; index < CONCURRENCY_STEPS.length; index += 1) {
        if (stopRequested.current) break;
        const concurrency = CONCURRENCY_STEPS[index];
        setCurrentStage(concurrency);
        setCurrentCompleted(0);
        const result = await runStage(concurrency);
        if (!result || stopRequested.current) break;
        setResults((previous) => [...previous, result]);
        setCurrentCompleted(0);
        if (index < CONCURRENCY_STEPS.length - 1) {
          await new Promise<void>((resolve) => {
            const timer = window.setTimeout(resolve, INTER_STEP_DELAY_MS);
            const poll = window.setInterval(() => {
              if (stopRequested.current) {
                window.clearTimeout(timer);
                window.clearInterval(poll);
                resolve();
              }
            }, 80);
            window.setTimeout(() => window.clearInterval(poll), INTER_STEP_DELAY_MS + 100);
          });
        }
      }
    } catch {
      setRunError('실험 중 요청을 처리하지 못했습니다. 서버 상태를 확인해 주세요.');
    } finally {
      activeControllers.current.forEach((controller) => controller.abort());
      activeControllers.current = [];
      setCurrentStage(null);
      setCurrentCompleted(0);
      setRunning(false);
      void metricsQuery.refetch();
    }
  }

  function stopRun() {
    stopRequested.current = true;
    activeControllers.current.forEach((controller) => controller.abort());
  }

  const completedRequests = results.reduce((sum, stage) => sum + stage.succeeded + stage.failed, 0) + currentCompleted;
  const progress = Math.round((completedRequests / 500) * 100);

  return (
    <Shell>
      <main className="page performance-page">
        <div className="lab-hero">
          <div>
            <div className="eyebrow">REQUEST / TRACE / LEARN</div>
            <h1 className="page-title">어디서 느려질까?</h1>
            <p className="page-subtitle">요청이 늘어날 때 API 응답과 서버 내부 측정값을 나란히 살펴봅니다.</p>
          </div>
          <div className="hero-stamp"><span>실험 설계</span><strong>5 × 100</strong></div>
        </div>
        <div className="sample-warning" role="note" data-testid="notice-experiment">
          <AlertTriangle size={17} />
          <span><strong>실험 데이터는 공식 벤치마크가 아닙니다.</strong> 아래 기준값은 단 한 번 수행한 과거 샘플입니다. 실행 환경에 따라 달라지며, 한 번의 실행만으로 병목 구간을 단정할 수 없습니다.</span>
        </div>

        <div className="lab-grid">
          <section className="panel section-panel" aria-labelledby="runner-title">
            <div className="section-heading">
              <div><h2 id="runner-title">동시 요청 실험</h2><p>각 단계에서 전형 일정 API에 총 100회 요청합니다.</p></div>
              <span className="type-tag">최대 500회</span>
            </div>
            <div className="levels" aria-label="실험 동시성 단계">
              {CONCURRENCY_STEPS.map((level) => <span key={level} className={`level-pill ${currentStage === level ? 'current' : ''}`}>{level}명</span>)}
            </div>
            <div className="run-actions">
              <button className="action-button" type="button" onClick={() => void startRun()} disabled={running} data-testid="button-start-test"><Play size={14} fill="currentColor" /> 실험 시작 · 총 500회</button>
              <button className="action-button secondary-button" type="button" onClick={stopRun} disabled={!running} data-testid="button-stop-test"><Square size={13} fill="currentColor" /> 중지</button>
            </div>
            <div className="run-status" role="status" data-testid="status-test-run">
              <span className={`status-dot ${running ? 'running' : ''}`} />
              {running ? `${currentStage ?? ''}명 단계 실행 중 · ${completedRequests}/500회 완료` : results.length ? `실험 ${completedRequests}/500회 완료${completedRequests < 500 ? ' · 중지됨' : ''}` : '대기 중 · 동시성별 100회, 단계 사이 2초 간격'}
            </div>
            {(running || results.length > 0) && <div className="run-progress" aria-label={`진행률 ${progress}%`}><span style={{ width: `${progress}%` }} /></div>}
            {runError && <div className="error-inline" role="alert" style={{ marginTop: 14 }}><span>{runError}</span><button className="small-link" type="button" onClick={() => setRunError('')}>닫기</button></div>}
            {results.length > 0 && (
              <div className="stage-results">
                <div className="table-scroll">
                  <table className="stage-table">
                    <thead><tr><th>동시성</th><th>평균</th><th>중앙값</th><th>p95</th><th>최소</th><th>최대</th><th>성공 / 실패</th><th>소요</th><th>RPS</th></tr></thead>
                    <tbody>
                      {results.map((result) => (
                        <tr key={result.concurrency} data-testid={`row-result-${result.concurrency}`}>
                          <td className="concurrency">{result.concurrency}명</td><td>{formatMs(result.average)}</td><td>{formatMs(result.median)}</td><td>{formatMs(result.p95)}</td><td>{formatMs(result.minimum)}</td><td>{formatMs(result.maximum)}</td>
                          <td><span className="success-text">{result.succeeded}</span> / <span className={result.failed ? 'fail-text' : ''}>{result.failed}</span></td>
                          <td>{(result.elapsed / 1000).toFixed(2)}초</td><td>{result.rps.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            <div className="baseline-card">
              <div className="baseline-title"><span>이전 실행 기준값</span><span>참고용 · 과거 1회</span></div>
              <p className="baseline-sub">역사적 샘플이며 공식 벤치마크나 현재 서버의 보장 성능이 아닙니다. 같은 조건으로 다시 측정해 비교하세요.</p>
              <div className="baseline-list">
                {BASELINE.map((item) => <div className="baseline-item" key={item.concurrency}><strong>{item.concurrency}명</strong><span>평균 {item.avg.toFixed(2)}ms</span><span>p95 {item.p95.toFixed(2)}ms</span><span>{item.rps.toFixed(2)} RPS</span></div>)}
              </div>
              <p className="caveat">기준 실행은 500회 모두 성공했습니다. 서로 다른 실행 조건의 수치를 직접적인 성능 보증으로 해석하지 마세요.</p>
            </div>
          </section>

          <section className="panel section-panel" aria-labelledby="metrics-title">
            <div className="section-heading">
              <div><h2 id="metrics-title">서버 측정 지표</h2><p>API → Python 프로세스 → SQLite 쿼리</p></div>
              <button className="icon-button" type="button" onClick={() => void metricsQuery.refetch()} aria-label="서버 지표 새로고침" data-testid="button-refresh-metrics"><RefreshCw size={14} /></button>
            </div>
            {metricsQuery.isLoading ? (
              <div className="metrics-stack" role="status" aria-label="서버 지표를 불러오는 중">{[0, 1, 2, 3].map((item) => <div className="metric-block" key={item}><div className="skeleton" style={{ width: '45%', height: 13 }} /><div className="skeleton" style={{ width: '80%', height: 25, marginTop: 13 }} /></div>)}</div>
            ) : metricsQuery.isError ? (
              <div className="error-state" role="alert" style={{ padding: '35px 8px' }}>
                <div className="empty-mark"><Server size={18} /></div><h3>서버 지표를 불러오지 못했습니다</h3><p>측정 API 연결을 확인해 주세요.</p>
                <button className="action-button" type="button" onClick={() => void metricsQuery.refetch()} data-testid="button-retry-metrics"><RefreshCw size={14} /> 다시 시도</button>
              </div>
            ) : metrics ? (
              <>
                <div className="metrics-stack">
                  <TimingBlock title="전체 API 응답" icon={<Gauge size={13} />} data={metrics.totalResponse} />
                  <TimingBlock title="Python 프로세스" icon={<Server size={13} />} data={metrics.pythonProcess} />
                  <TimingBlock title="SQLite 쿼리" icon={<Database size={13} />} data={metrics.sqliteQuery} />
                  <div className="metric-block">
                    <div className="metric-title"><span style={{ display: 'flex', alignItems: 'center', gap: 7 }}><Users size={13} /> 자원 사용</span><span>{metrics.resources.samples}개 관측</span></div>
                    <div className="resource-grid">
                      <ResourceCell label="API CPU 평균" value={`${numberValue(metrics.resources.apiServerAverageCpuPercent)}%`} />
                      <ResourceCell label="API CPU 최대" value={`${numberValue(metrics.resources.apiServerMaximumCpuPercent)}%`} />
                      <ResourceCell label="API RSS 평균" value={`${numberValue(metrics.resources.apiServerAverageRssMb)} MB`} />
                      <ResourceCell label="API RSS 최대" value={`${numberValue(metrics.resources.apiServerMaximumRssMb)} MB`} />
                      <ResourceCell label="Python CPU 평균" value={`${numberValue(metrics.resources.pythonAverageCpuPercent)}%`} />
                      <ResourceCell label="Python CPU 최대" value={`${numberValue(metrics.resources.pythonMaximumCpuPercent)}%`} />
                      <ResourceCell label="Python RSS 평균" value={`${numberValue(metrics.resources.pythonAverageRssMb)} MB`} />
                      <ResourceCell label="Python RSS 최대" value={`${numberValue(metrics.resources.pythonMaximumRssMb)} MB`} />
                      <ResourceCell label="평균 Python 프로세스" value={numberValue(metrics.resources.averagePythonProcesses)} />
                      <ResourceCell label="최대 Python 프로세스" value={numberValue(metrics.resources.maximumPythonProcesses)} />
                    </div>
                  </div>
                </div>
                <p className="caveat" data-testid="text-metrics-meta">측정 요청 {metrics.measuredRequests.toLocaleString('ko-KR')}회 · 관측 구간 {metrics.measurementWindow}<br />{metrics.note}</p>
              </>
            ) : (
              <div className="empty-state" style={{ padding: '35px 8px' }}><div className="empty-mark"><CircleHelp size={18} /></div><h3>표시할 서버 지표가 없습니다</h3><p>측정값이 쌓인 뒤 다시 확인해 주세요.</p></div>
            )}
            <p className="caveat"><strong>해석 주의:</strong> SQLite 측정 시간은 Python 프로세스 시간에 포함됩니다. 두 값을 독립 구간처럼 더하지 마세요. 한 번의 관측은 병목을 입증하지 않습니다.</p>
          </section>
        </div>
      </main>
    </Shell>
  );
}

function TimingBlock({ title, icon, data }: { title: string; icon: ReactNode; data: { averageMs: number; medianMs: number; p95Ms: number; minimumMs: number; maximumMs: number; samples: number } }) {
  return (
    <div className="metric-block">
      <div className="metric-title"><span style={{ display: 'flex', alignItems: 'center', gap: 7 }}>{icon}{title}</span><span>{data.samples}개 측정</span></div>
      <div className="metric-grid">
        <MetricValue label="평균" value={formatMs(data.averageMs)} />
        <MetricValue label="중앙값" value={formatMs(data.medianMs)} />
        <MetricValue label="p95" value={formatMs(data.p95Ms)} />
        <MetricValue label="최소" value={formatMs(data.minimumMs)} />
        <MetricValue label="최대" value={formatMs(data.maximumMs)} />
        <MetricValue label="표본" value={numberValue(data.samples)} />
      </div>
    </div>
  );
}

function MetricValue({ label, value }: { label: string; value: string }) {
  return <div className="metric-val"><small>{label}</small><b>{value}</b></div>;
}

function ResourceCell({ label, value }: { label: string; value: string }) {
  return <div className="resource-cell"><small>{label}</small><b>{value}</b></div>;
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={AdmissionsPage} />
        <Route path="/performance" component={PerformancePage} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
