#!/usr/bin/env python3
"""Small SQLite repository used by the admissions performance experiment."""

from __future__ import annotations

import json
import sqlite3
import sys
import time
from pathlib import Path
from typing import Any

DATA_DIR = Path(__file__).with_name("data")
DB_PATH = DATA_DIR / "admissions.db"

# Names are familiar to Korean students; every schedule field is synthetic.
SEED_ROWS = [
    (1, "서울대학교", "학생부종합", "2026-09-08", "2026-09-10", "2026-11-10", "2026-11-21", "2026-12-12", "성능 실험용 가상 일정"),
    (2, "연세대학교", "학생부종합", "2026-09-09", "2026-09-11", "2026-11-11", "2026-11-22", "2026-12-13", "성능 실험용 가상 일정"),
    (3, "고려대학교", "학생부종합", "2026-09-10", "2026-09-12", "2026-11-12", "2026-11-23", "2026-12-14", "성능 실험용 가상 일정"),
    (4, "성균관대학교", "논술", "2026-09-11", "2026-09-13", "2026-11-13", "2026-11-28", "2026-12-15", "성능 실험용 가상 일정"),
    (5, "한양대학교", "논술", "2026-09-12", "2026-09-14", "2026-11-14", "2026-11-29", "2026-12-16", "성능 실험용 가상 일정"),
    (6, "중앙대학교", "학생부교과", "2026-09-13", "2026-09-15", "2026-11-15", None, "2026-12-17", "성능 실험용 가상 일정"),
    (7, "경희대학교", "학생부종합", "2026-09-14", "2026-09-16", "2026-11-16", "2026-11-30", "2026-12-18", "성능 실험용 가상 일정"),
    (8, "이화여자대학교", "논술", "2026-09-15", "2026-09-17", "2026-11-17", "2026-12-01", "2026-12-19", "성능 실험용 가상 일정"),
    (9, "서강대학교", "학생부종합", "2026-09-16", "2026-09-18", "2026-11-18", "2026-12-02", "2026-12-20", "성능 실험용 가상 일정"),
    (10, "한국외국어대학교", "학생부교과", "2026-09-17", "2026-09-19", "2026-11-19", None, "2026-12-21", "성능 실험용 가상 일정"),
    (11, "서울대학교", "논술", "2026-09-18", "2026-09-20", "2026-11-20", "2026-12-03", "2026-12-22", "성능 실험용 가상 일정"),
    (12, "연세대학교", "학생부교과", "2026-09-19", "2026-09-21", "2026-11-21", "2026-12-04", "2026-12-23", "성능 실험용 가상 일정"),
]


def connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH, timeout=15)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA busy_timeout = 15000")
    connection.execute("PRAGMA journal_mode = WAL")
    return connection


def ensure_database(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS admissions (
            id INTEGER PRIMARY KEY,
            university TEXT NOT NULL,
            admission_type TEXT NOT NULL,
            application_start TEXT NOT NULL,
            application_end TEXT NOT NULL,
            document_deadline TEXT NOT NULL,
            exam_date TEXT,
            result_date TEXT,
            notes TEXT NOT NULL
        )
        """
    )
    with connection:
        if connection.execute("SELECT COUNT(*) FROM admissions").fetchone()[0] == 0:
            connection.executemany(
                """
                INSERT INTO admissions
                    (id, university, admission_type, application_start,
                     application_end, document_deadline, exam_date, result_date, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                SEED_ROWS,
            )


def admission_result(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "university": row["university"],
        "admissionType": row["admission_type"],
        "applicationStart": row["application_start"],
        "applicationEnd": row["application_end"],
        "documentDeadline": row["document_deadline"],
        "examDate": row["exam_date"],
        "resultDate": row["result_date"],
        "notes": row["notes"],
        "isSample": True,
    }


def list_admissions(filters: dict[str, Any]) -> dict[str, Any]:
    connection = connect()
    try:
        ensure_database(connection)
        clauses: list[str] = []
        values: list[str] = []
        search = (filters.get("search") or "").strip()
        if search:
            clauses.append(
                "(university LIKE ? ESCAPE '\\' OR admission_type LIKE ? ESCAPE '\\' OR notes LIKE ? ESCAPE '\\')"
            )
            escaped = search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            pattern = f"%{escaped}%"
            values.extend([pattern, pattern, pattern])
        if filters.get("university"):
            clauses.append("university LIKE ? ESCAPE '\\'")
            university = filters["university"].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            values.append(f"%{university}%")
        if filters.get("admissionType"):
            clauses.append("admission_type = ?")
            values.append(filters["admissionType"])

        sort_columns = {"date": "document_deadline", "university": "university"}
        sort_column = sort_columns.get(filters.get("sort"), "application_start")
        direction = "DESC" if filters.get("direction") == "desc" else "ASC"
        where = f" WHERE {' AND '.join(clauses)}" if clauses else ""

        started = time.perf_counter()
        rows = connection.execute(
            f"SELECT * FROM admissions{where} ORDER BY {sort_column} {direction}, id ASC",
            values,
        ).fetchall()
        sqlite_query_ms = (time.perf_counter() - started) * 1000
        return {
            "items": [admission_result(row) for row in rows],
            "sqliteQueryMs": round(sqlite_query_ms, 3),
        }
    finally:
        connection.close()


def admissions_summary() -> dict[str, Any]:
    connection = connect()
    try:
        ensure_database(connection)
        started = time.perf_counter()
        row = connection.execute(
            """
            SELECT COUNT(*) AS total,
                   COUNT(DISTINCT university) AS universities,
                   COUNT(DISTINCT admission_type) AS admission_types,
                   MIN(CASE WHEN document_deadline >= date('now')
                            THEN document_deadline END) AS next_deadline
            FROM admissions
            """
        ).fetchone()
        sqlite_query_ms = (time.perf_counter() - started) * 1000
        return {
            "summary": {
                "total": row["total"],
                "universities": row["universities"],
                "admissionTypes": row["admission_types"],
                "nextDeadline": row["next_deadline"],
                "sampleData": True,
            },
            "sqliteQueryMs": round(sqlite_query_ms, 3),
        }
    finally:
        connection.close()


def main() -> None:
    if len(sys.argv) != 3:
        raise ValueError("Expected an operation and JSON parameters.")
    operation = sys.argv[1]
    parameters = json.loads(sys.argv[2])
    if operation == "list":
        result = list_admissions(parameters)
    elif operation == "summary":
        result = admissions_summary()
    else:
        raise ValueError(f"Unsupported repository operation: {operation}")
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))


if __name__ == "__main__":
    main()
