#!/usr/bin/env python3
"""Repeatable local-only load test for the admissions API."""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import math
import os
import pathlib
import re
import statistics
import threading
import time
import urllib.error
import urllib.request
from typing import Any
from urllib.parse import urlparse

CONCURRENCY_LEVELS = (1, 10, 25, 50, 100)
REQUESTS_PER_LEVEL = 100
PAUSE_BETWEEN_LEVELS_SECONDS = 2

# Historical single-run observations supplied in the project brief.
# These values are a reference only, not a statistically verified control group.
HISTORICAL_BASELINE = {
    1: {"averageMs": 74.88, "p95Ms": 93.10, "rps": 13.34},
    10: {"averageMs": 333.31, "p95Ms": 531.84, "rps": 29.33},
    25: {"averageMs": 939.68, "p95Ms": 1563.36, "rps": 25.33},
    50: {"averageMs": 1832.93, "p95Ms": 4092.94, "rps": 23.27},
    100: {"averageMs": 1763.25, "p95Ms": 2619.98, "rps": 34.83},
}


def percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    return ordered[max(0, math.ceil(len(ordered) * fraction) - 1)]


def server_timing_value(header: str, metric: str) -> float | None:
    match = re.search(rf"(?:^|,)\s*{re.escape(metric)};dur=([\d.]+)", header)
    return float(match.group(1)) if match else None


def fetch_one(url: str, timeout: float, headers: dict[str, str]) -> dict[str, Any]:
    started = time.perf_counter()
    try:
        request = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": "AdmissionsLocalLoadTest/1.0",
                **headers,
            },
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            response.read()
            elapsed_ms = (time.perf_counter() - started) * 1000
            timing = response.headers.get("Server-Timing", "")
            return {
                "ok": 200 <= response.status < 300,
                "status": response.status,
                "elapsedMs": elapsed_ms,
                "pythonProcessMs": server_timing_value(timing, "pythonProcess"),
                "sqliteQueryMs": server_timing_value(timing, "sqliteQuery"),
                "cacheStatus": response.headers.get("X-Admissions-Cache", "BYPASS"),
                "instancePid": response.headers.get("X-API-Instance-PID"),
                "processRoot": response.headers.get("X-API-Process-Root"),
            }
    except urllib.error.HTTPError as error:
        return {
            "ok": False,
            "status": error.code,
            "elapsedMs": (time.perf_counter() - started) * 1000,
            "error": str(error),
        }
    except Exception as error:  # network failures are part of the test result
        return {
            "ok": False,
            "status": None,
            "elapsedMs": (time.perf_counter() - started) * 1000,
            "error": str(error),
        }


def read_process_tree(root_pid: int) -> dict[int, dict[str, Any]]:
    processes: dict[int, dict[str, Any]] = {}
    try:
        entries = list(os.scandir("/proc"))
    except OSError:
        return processes
    for entry in entries:
        if not entry.name.isdigit():
            continue
        pid = int(entry.name)
        try:
            stat = pathlib.Path(f"/proc/{pid}/stat").read_text()
            closing_paren = stat.rfind(")")
            fields = stat[closing_paren + 2 :].split()
            command = pathlib.Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
            status = pathlib.Path(f"/proc/{pid}/status").read_text()
            rss_match = re.search(r"^VmRSS:\s+(\d+)\s+kB$", status, re.MULTILINE)
            processes[pid] = {
                "parent": int(fields[1]),
                "ticks": int(fields[11]) + int(fields[12]),
                "rssMb": int(rss_match.group(1)) / 1024 if rss_match else 0.0,
                "isPythonRepository": "admissions_repository.py" in command,
            }
        except (OSError, ValueError, IndexError):
            continue

    descendants: dict[int, list[int]] = {}
    for pid, process in processes.items():
        descendants.setdefault(process["parent"], []).append(pid)
    members: list[int] = []
    pending = [root_pid]
    while pending:
        parent = pending.pop()
        if parent in members:
            continue
        members.append(parent)
        pending.extend(descendants.get(parent, []))
    return {pid: processes[pid] for pid in members if pid in processes}


class ProcessTreeSampler:
    def __init__(self, root_pid: int, interval_seconds: float = 0.1):
        self.root_pid = root_pid
        self.interval_seconds = interval_seconds
        self.samples: list[dict[str, float]] = []
        self.previous_ticks: dict[int, int] = {}
        self.previous_at: float | None = None
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)

    def start(self) -> None:
        self.sample()
        self.thread.start()

    def stop(self) -> dict[str, Any]:
        self.stop_event.set()
        self.thread.join(timeout=2)
        self.sample()
        return {
            "apiCpuPercent": resource_summary([sample["apiCpuPercent"] for sample in self.samples]),
            "apiRssMb": resource_summary([sample["apiRssMb"] for sample in self.samples]),
            "pythonCpuPercent": resource_summary([sample["pythonCpuPercent"] for sample in self.samples]),
            "pythonRssMb": resource_summary([sample["pythonRssMb"] for sample in self.samples]),
            "pythonProcesses": resource_summary([sample["pythonProcesses"] for sample in self.samples]),
            "samples": len(self.samples),
            "samplingIntervalMs": round(self.interval_seconds * 1000),
        }

    def _run(self) -> None:
        while not self.stop_event.wait(self.interval_seconds):
            self.sample()

    def sample(self) -> None:
        now = time.perf_counter()
        processes = read_process_tree(self.root_pid)
        elapsed = now - self.previous_at if self.previous_at is not None else 0
        api_ticks = 0
        python_ticks = 0
        api_rss = 0.0
        python_rss = 0.0
        python_processes = 0
        for pid, process in processes.items():
            old_ticks = self.previous_ticks.get(pid)
            if elapsed > 0 and old_ticks is not None:
                delta = max(0, process["ticks"] - old_ticks)
                if process["isPythonRepository"]:
                    python_ticks += delta
                else:
                    api_ticks += delta
            if process["isPythonRepository"]:
                python_processes += 1
                python_rss += process["rssMb"]
            else:
                api_rss += process["rssMb"]
            self.previous_ticks[pid] = process["ticks"]

        tick_rate = os.sysconf("SC_CLK_TCK")
        self.samples.append(
            {
                "apiCpuPercent": api_ticks / tick_rate / elapsed * 100 if elapsed > 0 else 0,
                "apiRssMb": api_rss,
                "pythonCpuPercent": python_ticks / tick_rate / elapsed * 100 if elapsed > 0 else 0,
                "pythonRssMb": python_rss,
                "pythonProcesses": float(python_processes),
            }
        )
        self.previous_at = now


def resource_summary(values: list[float]) -> dict[str, float | int]:
    if not values:
        return {"average": 0, "maximum": 0}
    return {"average": round(statistics.fmean(values), 3), "maximum": round(max(values), 3)}


def read_process_root(url: str, timeout: float) -> int:
    request = urllib.request.Request(
        url,
        headers={"Accept": "application/json", "User-Agent": "AdmissionsLocalLoadTest/1.0"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        response.read()
        root = response.headers.get("X-API-Process-Root")
    if not root or not root.isdigit():
        raise RuntimeError("API did not provide a local process-tree root for resource sampling.")
    return int(root)


def run_stage(
    url: str,
    concurrency: int,
    request_count: int,
    timeout: float,
    variant: str,
    process_root: int,
) -> dict[str, Any]:
    stage_started = time.perf_counter()
    headers: dict[str, str] = {}
    if variant == "cache":
        headers = {
            "X-Admissions-Performance-Cache": "1",
            "X-Admissions-Cache-Run": f"{os.getpid()}-{time.time_ns()}-{concurrency}",
        }
    sampler = ProcessTreeSampler(process_root)
    sampler.start()
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
            results = list(
                executor.map(
                    lambda _: fetch_one(url, timeout, headers),
                    range(request_count),
                )
            )
    finally:
        resources = sampler.stop()
    duration_seconds = time.perf_counter() - stage_started
    latencies = [result["elapsedMs"] for result in results]
    python_times = [result["pythonProcessMs"] for result in results if result.get("pythonProcessMs") is not None]
    sqlite_times = [result["sqliteQueryMs"] for result in results if result.get("sqliteQueryMs") is not None]
    successes = sum(1 for result in results if result["ok"])
    instance_requests: dict[str, int] = {}
    root_pids: set[str] = set()
    cache_statuses: dict[str, int] = {}
    for result in results:
        if result.get("instancePid"):
            instance_requests[result["instancePid"]] = instance_requests.get(result["instancePid"], 0) + 1
        if result.get("processRoot"):
            root_pids.add(result["processRoot"])
        status = result.get("cacheStatus", "BYPASS")
        cache_statuses[status] = cache_statuses.get(status, 0) + 1
    return {
        "concurrency": concurrency,
        "variant": variant,
        "requests": request_count,
        "successes": successes,
        "failures": request_count - successes,
        "durationSeconds": round(duration_seconds, 3),
        "rps": round(successes / duration_seconds, 2) if duration_seconds else 0,
        "responseMs": timing_summary(latencies),
        "pythonProcessMs": timing_summary(python_times),
        "sqliteQueryMs": timing_summary(sqlite_times),
        "resources": resources,
        "cacheStatuses": cache_statuses,
        "instanceRequests": instance_requests,
        "processRootPids": sorted(root_pids),
        "errors": [result["error"] for result in results if result.get("error")][:10],
        "historicalBaseline": HISTORICAL_BASELINE[concurrency],
    }


def timing_summary(values: list[float]) -> dict[str, float | int]:
    if not values:
        return {
            "average": 0,
            "median": 0,
            "p95": 0,
            "minimum": 0,
            "maximum": 0,
            "samples": 0,
        }
    return {
        "average": round(statistics.fmean(values), 3),
        "median": round(statistics.median(values), 3),
        "p95": round(percentile(values, 0.95), 3),
        "minimum": round(min(values), 3),
        "maximum": round(max(values), 3),
        "samples": len(values),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--url",
        default="http://localhost:80/api/admissions",
        help="Local admissions endpoint (default: %(default)s)",
    )
    parser.add_argument("--timeout", type=float, default=30.0, help="Request timeout in seconds")
    parser.add_argument("--requests", type=int, default=REQUESTS_PER_LEVEL, help="Requests per level")
    parser.add_argument("--pause", type=float, default=PAUSE_BETWEEN_LEVELS_SECONDS, help="Seconds between levels")
    parser.add_argument(
        "--variant",
        choices=("baseline", "cache", "distributed"),
        default="baseline",
        help="Experiment treatment; cache mode sends the opt-in cache header",
    )
    parser.add_argument("--output", help="Optional path for the complete JSON result")
    args = parser.parse_args()
    if args.requests < 1 or args.pause < 0 or args.timeout <= 0:
        parser.error("--requests and --timeout must be positive, and --pause cannot be negative")
    parsed_url = urlparse(args.url)
    if (
        parsed_url.scheme != "http"
        or parsed_url.hostname not in {"localhost", "127.0.0.1", "::1"}
        or parsed_url.path.rstrip("/") != "/api/admissions"
    ):
        parser.error("This experiment is restricted to a local API endpoint.")

    process_root = read_process_root(args.url, args.timeout)
    started_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    stages = []
    for index, concurrency in enumerate(CONCURRENCY_LEVELS):
        stages.append(
            run_stage(
                args.url,
                concurrency,
                args.requests,
                args.timeout,
                args.variant,
                process_root,
            )
        )
        if index < len(CONCURRENCY_LEVELS) - 1:
            time.sleep(args.pause)

    output = {
        "target": args.url,
        "startedAt": started_at,
        "variant": args.variant,
        "requestsPerLevel": args.requests,
        "pauseSeconds": args.pause,
        "stages": stages,
        "interpretation": (
            "CPU, RSS and Python process counts are sampled from the local API process tree "
            "every 100ms for each stage. Short-lived Python processes can be missed. "
            "SQLite query time is part of Python process time; do not sum them. "
            "One run is exploratory, not conclusive."
        ),
    }
    rendered = json.dumps(output, ensure_ascii=False, indent=2)
    if args.output:
        pathlib.Path(args.output).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
